from flask import Flask, render_template, request
import ast

app = Flask(__name__)

# Load the drug interactions from the file
with open('drug_interactions.txt', 'r') as file:
    data = file.read()

drug_interactions = ast.literal_eval(data)

@app.route('/', methods=['GET', 'POST'])
def home():
    drug_list = list(drug_interactions.keys())  # Extract all drug names
    if request.method == 'POST':
        drugs = request.form['drugs'].split(',')
        result = check_drug_interaction([drug.strip() for drug in drugs])  # Clean input
        return render_template('result.html', result=result)
    return render_template('index.html', drug_list=drug_list)

def check_drug_interaction(current_drugs):
    interactions = set()
    for drug1 in current_drugs:
        for drug2 in current_drugs:
            if drug1 != drug2 and drug2 in drug_interactions.get(drug1, []):
                interactions.add((drug1, drug2))
    if interactions:
        interaction_list = [f"{drug1} ↔ {drug2}" for drug1, drug2 in interactions]
        return {
            "message": "Warning: Drug interactions detected.",
            "interactions": interaction_list,
            "class": "interaction-found"
        }
    return {
        "message": "No known drug interactions in the current medication list.",
        "class": "no-interaction"
    }

if __name__ == '__main__':
    app.run(debug=True)

