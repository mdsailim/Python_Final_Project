from setuptools import setup

setup( 
    name='project drug-drug interaction',  
    version='1.1.0',  
    description='Cardiovascular Drug-Drug Interaction', 
    author='Sailim Ullah', 
    author_email='sailim08@gmail.com', 
    url='salimcods.com', 
    py_modules=['Project']
)
